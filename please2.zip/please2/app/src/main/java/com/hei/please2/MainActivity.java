package com.hei.please2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.ViewGroup;

import net.daum.mf.map.api.MapLayout;
import net.daum.mf.map.api.MapPOIItem;
import net.daum.mf.map.api.MapPoint;
import net.daum.mf.map.api.MapView;

public class MainActivity extends AppCompatActivity implements MapView.MapViewEventListener {
    private static final MapPoint CUSTOM_MARKER_POINT = MapPoint.mapPointWithGeoCoord(37.537229, 127.005515);
    private static final MapPoint CUSTOM_MARKER_POINT2 = MapPoint.mapPointWithGeoCoord(37.447229, 127.015515);
    private static final String Daum_API_KEY = "0f6c455c8ff6fa7882f541e379300830";
    private MapPOIItem mCustomMarker;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );

        MapView mapView = new MapView ( this );
        mapView.setDaumMapApiKey ( Daum_API_KEY );
        ViewGroup mapViewContainer = (ViewGroup) findViewById ( R.id.map_view );
        mapViewContainer.addView ( mapView );

        mapView.setMapViewEventListener ( this );
    }

    @Override
    public void onMapViewInitialized(MapView mapView) {
        mapView.setMapCenterPoint(MapPoint.mapPointWithGeoCoord(36.8099687, 127.076489), true);


        MapPOIItem marker = new MapPOIItem();
        marker.setItemName("Default Marker");
        marker.setTag(0);
        marker.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8099687, 127.076489));
        marker.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker);

//////////////////////////////////////
        MapPOIItem marker1 = new MapPOIItem();
        marker1.setItemName("Default Marker");
        marker1.setTag(0);
        marker1.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8384015, 127.085486));
        marker1.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker1.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker1);
        //////////////////////////////////////
        MapPOIItem marker2 = new MapPOIItem();
        marker2.setItemName("Default Marker");
        marker2.setTag(0);
        marker2.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8779344, 127.017400));
        marker2.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker2.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker2);
        //////////////////////////////////////
        MapPOIItem marker3 = new MapPOIItem();
        marker3.setItemName("Default Marker");
        marker3.setTag(0);
        marker3.setMapPoint(MapPoint.mapPointWithGeoCoord(127.059349, 36.7731320));
        marker3.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker3.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker3);
        //////////////////////////////////////
        MapPOIItem marker4 = new MapPOIItem();
        marker4.setItemName("Default Marker");
        marker4.setTag(0);
        marker4.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7822019, 126.992230));
        marker4.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker4.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker4);
        //////////////////////////////////////
        MapPOIItem marker5 = new MapPOIItem();
        marker5.setItemName("Default Marker");
        marker5.setTag(0);
        marker5.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7807873, 127.008866));
        marker5.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker5.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker5);
        //////////////////////////////////////
        MapPOIItem marker6 = new MapPOIItem();
        marker6.setItemName("Default Marker");
        marker6.setTag(0);
        marker6.setMapPoint(MapPoint.mapPointWithGeoCoord(126.912610, 36.7466563));
        marker6.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker6.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker6);
        //////////////////////////////////////
        MapPOIItem marker7 = new MapPOIItem();
        marker7.setItemName("Default Marker");
        marker7.setTag(0);
        marker7.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker7.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker7.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker7);
        //////////////////////////////////////
        MapPOIItem marker8 = new MapPOIItem();
        marker8.setItemName("Default Marker");
        marker8.setTag(0);
        marker8.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker8.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker8.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker8);

        //////////////////////////////////////
        MapPOIItem marker9 = new MapPOIItem();
        marker9.setItemName("Default Marker");
        marker9.setTag(0);
        marker9.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker9.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker9.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker9);


        MapPOIItem marker10 = new MapPOIItem();
        marker10.setItemName("Default Marker");
        marker10.setTag(0);
        marker10.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8099687, 127.076489));
        marker10.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker10.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker10);

//////////////////////////////////////
        MapPOIItem marker11 = new MapPOIItem();
        marker11.setItemName("Default Marker");
        marker11.setTag(0);
        marker11.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8384015, 127.085486));
        marker11.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker11.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker11);
        //////////////////////////////////////
        MapPOIItem marker12 = new MapPOIItem();
        marker12.setItemName("Default Marker");
        marker12.setTag(0);
        marker12.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8779344, 127.017400));
        marker12.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker12.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker12);
        //////////////////////////////////////
        MapPOIItem marker13 = new MapPOIItem();
        marker13.setItemName("Default Marker");
        marker13.setTag(0);
        marker13.setMapPoint(MapPoint.mapPointWithGeoCoord(127.059349, 36.7731320));
        marker13.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker13.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker3);
        //////////////////////////////////////
        MapPOIItem marker14 = new MapPOIItem();
        marker14.setItemName("Default Marker");
        marker14.setTag(0);
        marker14.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7822019, 126.992230));
        marker14.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker14.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker14);
        //////////////////////////////////////
        MapPOIItem marker15 = new MapPOIItem();
        marker15.setItemName("Default Marker");
        marker15.setTag(0);
        marker15.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7807873, 127.008866));
        marker15.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker15.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker15);
        //////////////////////////////////////
        MapPOIItem marker16 = new MapPOIItem();
        marker16.setItemName("Default Marker");
        marker16.setTag(0);
        marker16.setMapPoint(MapPoint.mapPointWithGeoCoord(126.912610, 36.7466563));
        marker16.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker16.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker16);
        //////////////////////////////////////
        MapPOIItem marker17 = new MapPOIItem();
        marker17.setItemName("Default Marker");
        marker17.setTag(0);
        marker17.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker17.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker17.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker17);
        //////////////////////////////////////
        MapPOIItem marker18 = new MapPOIItem();
        marker18.setItemName("Default Marker");
        marker18.setTag(0);
        marker18.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker18.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker18.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker18);

        //////////////////////////////////////
        MapPOIItem marker19 = new MapPOIItem();
        marker19.setItemName("Default Marker");
        marker19.setTag(0);
        marker19.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker19.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker19.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker19);
        MapPOIItem marker20 = new MapPOIItem();
        marker20.setItemName("Default Marker");
        marker20.setTag(0);
        marker20.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8099687, 127.076489));
        marker20.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker20.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker20);

//////////////////////////////////////
        MapPOIItem marker21 = new MapPOIItem();
        marker21.setItemName("Default Marker");
        marker21.setTag(0);
        marker21.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8384015, 127.085486));
        marker21.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker21.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker21);
        //////////////////////////////////////
        MapPOIItem marker22 = new MapPOIItem();
        marker22.setItemName("Default Marker");
        marker22.setTag(0);
        marker22.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8779344, 127.017400));
        marker22.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker22.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker22);
        //////////////////////////////////////
        MapPOIItem marker23 = new MapPOIItem();
        marker23.setItemName("Default Marker");
        marker23.setTag(0);
        marker23.setMapPoint(MapPoint.mapPointWithGeoCoord(127.059349, 36.7731320));
        marker23.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker23.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker23);
        //////////////////////////////////////
        MapPOIItem marker24 = new MapPOIItem();
        marker24.setItemName("Default Marker");
        marker24.setTag(0);
        marker24.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7822019, 126.992230));
        marker24.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker24.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker24);
        //////////////////////////////////////
        MapPOIItem marker25 = new MapPOIItem();
        marker25.setItemName("Default Marker");
        marker25.setTag(0);
        marker25.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7807873, 127.008866));
        marker25.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker25.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker25);
        //////////////////////////////////////
        MapPOIItem marker26 = new MapPOIItem();
        marker26.setItemName("Default Marker");
        marker26.setTag(0);
        marker26.setMapPoint(MapPoint.mapPointWithGeoCoord(126.912610, 36.7466563));
        marker26.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker26.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker26);
        //////////////////////////////////////
        MapPOIItem marker27 = new MapPOIItem();
        marker27.setItemName("Default Marker");
        marker27.setTag(0);
        marker27.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker27.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker27.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker27);
        //////////////////////////////////////
        MapPOIItem marker28 = new MapPOIItem();
        marker28.setItemName("Default Marker");
        marker28.setTag(0);
        marker28.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker28.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker28.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker8);

        //////////////////////////////////////
        MapPOIItem marker29 = new MapPOIItem();
        marker9.setItemName("Default Marker");
        marker9.setTag(0);
        marker9.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker9.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker9.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker29);
        MapPOIItem marker30 = new MapPOIItem();
        marker30.setItemName("Default Marker");
        marker30.setTag(0);
        marker30.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8099687, 127.076489));
        marker30.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker30.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker30);

//////////////////////////////////////
        MapPOIItem marker31 = new MapPOIItem();
        marker31.setItemName("Default Marker");
        marker31.setTag(0);
        marker31.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8384015, 127.085486));
        marker31.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker31.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker31);
        //////////////////////////////////////
        MapPOIItem marker32 = new MapPOIItem();
        marker32.setItemName("Default Marker");
        marker32.setTag(0);
        marker32.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8779344, 127.017400));
        marker32.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker32.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker32);
        //////////////////////////////////////
        MapPOIItem marker33 = new MapPOIItem();
        marker33.setItemName("Default Marker");
        marker33.setTag(0);
        marker33.setMapPoint(MapPoint.mapPointWithGeoCoord(127.059349, 36.7731320));
        marker33.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker33.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker33);
        //////////////////////////////////////
        MapPOIItem marker34 = new MapPOIItem();
        marker34.setItemName("Default Marker");
        marker34.setTag(0);
        marker34.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7822019, 126.992230));
        marker34.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker34.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker34);
        //////////////////////////////////////
        MapPOIItem marker35 = new MapPOIItem();
        marker35.setItemName("Default Marker");
        marker35.setTag(0);
        marker35.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7807873, 127.008866));
        marker35.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker35.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker35);
        //////////////////////////////////////
        MapPOIItem marker36 = new MapPOIItem();
        marker36.setItemName("Default Marker");
        marker36.setTag(0);
        marker36.setMapPoint(MapPoint.mapPointWithGeoCoord(126.912610, 36.7466563));
        marker36.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker36.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker36);
        //////////////////////////////////////
        MapPOIItem marker37 = new MapPOIItem();
        marker37.setItemName("Default Marker");
        marker37.setTag(0);
        marker37.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker37.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker37.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker37);
        //////////////////////////////////////
        MapPOIItem marker38 = new MapPOIItem();
        marker38.setItemName("Default Marker");
        marker38.setTag(0);
        marker38.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker38.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker38.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker38);

        //////////////////////////////////////
        MapPOIItem marker39 = new MapPOIItem();
        marker39.setItemName("Default Marker");
        marker39.setTag(0);
        marker39.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker39.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker39.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker39);
        MapPOIItem marker40 = new MapPOIItem();
        marker40.setItemName("Default Marker");
        marker40.setTag(0);
        marker40.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8099687, 127.076489));
        marker40.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker40.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker40);

//////////////////////////////////////
        MapPOIItem marker41 = new MapPOIItem();
        marker41.setItemName("Default Marker");
        marker41.setTag(0);
        marker41.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8384015, 127.085486));
        marker41.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker41.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker1);
        //////////////////////////////////////
        MapPOIItem marker42 = new MapPOIItem();
        marker42.setItemName("Default Marker");
        marker42.setTag(0);
        marker42.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8779344, 127.017400));
        marker42.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker42.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker42);
        //////////////////////////////////////
        MapPOIItem marker43 = new MapPOIItem();
        marker43.setItemName("Default Marker");
        marker43.setTag(0);
        marker43.setMapPoint(MapPoint.mapPointWithGeoCoord(127.059349, 36.7731320));
        marker43.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker43.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker3);
        //////////////////////////////////////
        MapPOIItem marker44 = new MapPOIItem();
        marker44.setItemName("Default Marker");
        marker44.setTag(0);
        marker44.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7822019, 126.992230));
        marker44.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker44.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker44);
        //////////////////////////////////////
        MapPOIItem marker45 = new MapPOIItem();
        marker45.setItemName("Default Marker");
        marker45.setTag(0);
        marker45.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7807873, 127.008866));
        marker45.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker45.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker45);
        //////////////////////////////////////
        MapPOIItem marker46 = new MapPOIItem();
        marker46.setItemName("Default Marker");
        marker46.setTag(0);
        marker46.setMapPoint(MapPoint.mapPointWithGeoCoord(126.912610, 36.7466563));
        marker46.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker46.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker46);
        //////////////////////////////////////
        MapPOIItem marker47 = new MapPOIItem();
        marker47.setItemName("Default Marker");
        marker47.setTag(0);
        marker47.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker47.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker47.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker7);
        //////////////////////////////////////
        MapPOIItem marker48 = new MapPOIItem();
        marker48.setItemName("Default Marker");
        marker48.setTag(0);
        marker48.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker48.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker48.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker48);

        //////////////////////////////////////
        MapPOIItem marker49 = new MapPOIItem();
        marker49.setItemName("Default Marker");
        marker49.setTag(0);
        marker49.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker49.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker49.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker49);
        MapPOIItem marker50 = new MapPOIItem();
        marker50.setItemName("Default Marker");
        marker50.setTag(0);
        marker50.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8099687, 127.076489));
        marker50.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker50.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker50);

//////////////////////////////////////
        MapPOIItem marker51 = new MapPOIItem();
        marker51.setItemName("Default Marker");
        marker51.setTag(0);
        marker51.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8384015, 127.085486));
        marker51.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker51.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker51);
        //////////////////////////////////////
        MapPOIItem marker52 = new MapPOIItem();
        marker52.setItemName("Default Marker");
        marker52.setTag(0);
        marker52.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8779344, 127.017400));
        marker52.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker52.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker52);
        //////////////////////////////////////
        MapPOIItem marker53 = new MapPOIItem();
        marker53.setItemName("Default Marker");
        marker53.setTag(0);
        marker53.setMapPoint(MapPoint.mapPointWithGeoCoord(127.059349, 36.7731320));
        marker53.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker53.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker53);
        //////////////////////////////////////
        MapPOIItem marker54 = new MapPOIItem();
        marker54.setItemName("Default Marker");
        marker54.setTag(0);
        marker54.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7822019, 126.992230));
        marker54.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker54.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker54);
        //////////////////////////////////////
        MapPOIItem marker55 = new MapPOIItem();
        marker55.setItemName("Default Marker");
        marker55.setTag(0);
        marker55.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7807873, 127.008866));
        marker55.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker55.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker55);
        //////////////////////////////////////
        MapPOIItem marker56 = new MapPOIItem();
        marker56.setItemName("Default Marker");
        marker56.setTag(0);
        marker56.setMapPoint(MapPoint.mapPointWithGeoCoord(126.912610, 36.7466563));
        marker56.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker56.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker56);
        //////////////////////////////////////
        MapPOIItem marker57 = new MapPOIItem();
        marker57.setItemName("Default Marker");
        marker57.setTag(0);
        marker57.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker57.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker57.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker57);
        //////////////////////////////////////
        MapPOIItem marker58 = new MapPOIItem();
        marker58.setItemName("Default Marker");
        marker58.setTag(0);
        marker58.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker58.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker58.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker58);

        //////////////////////////////////////
        MapPOIItem marker59 = new MapPOIItem();
        marker59.setItemName("Default Marker");
        marker59.setTag(0);
        marker59.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker59.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker59.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker59);
        MapPOIItem marker60 = new MapPOIItem();
        marker60.setItemName("Default Marker");
        marker60.setTag(0);
        marker60.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8099687, 127.076489));
        marker60.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker60.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker60);

//////////////////////////////////////
        MapPOIItem marker61 = new MapPOIItem();
        marker61.setItemName("Default Marker");
        marker61.setTag(0);
        marker61.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8384015, 127.085486));
        marker61.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker61.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker61);
        //////////////////////////////////////
        MapPOIItem marker62 = new MapPOIItem();
        marker62.setItemName("Default Marker");
        marker62.setTag(0);
        marker62.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8779344, 127.017400));
        marker62.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker62.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker62);
        //////////////////////////////////////
        MapPOIItem marker63 = new MapPOIItem();
        marker63.setItemName("Default Marker");
        marker63.setTag(0);
        marker63.setMapPoint(MapPoint.mapPointWithGeoCoord(127.059349, 36.7731320));
        marker63.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker63.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker63);
        //////////////////////////////////////
        MapPOIItem marker64 = new MapPOIItem();
        marker64.setItemName("Default Marker");
        marker64.setTag(0);
        marker64.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7822019, 126.992230));
        marker64.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker64.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker64);
        //////////////////////////////////////
        MapPOIItem marker65 = new MapPOIItem();
        marker65.setItemName("Default Marker");
        marker65.setTag(0);
        marker65.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7807873, 127.008866));
        marker65.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker65.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker65);
        //////////////////////////////////////
        MapPOIItem marker66 = new MapPOIItem();
        marker66.setItemName("Default Marker");
        marker66.setTag(0);
        marker66.setMapPoint(MapPoint.mapPointWithGeoCoord(126.912610, 36.7466563));
        marker66.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker66.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker66);
        //////////////////////////////////////
        MapPOIItem marker67 = new MapPOIItem();
        marker67.setItemName("Default Marker");
        marker67.setTag(0);
        marker67.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker67.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker67.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker67);
        //////////////////////////////////////


    }



    public void setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode trackingMode){

    }
    @Override
    public void onMapViewCenterPointMoved(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewZoomLevelChanged(MapView mapView, int i) {

    }

    @Override
    public void onMapViewSingleTapped(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewDoubleTapped(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewLongPressed(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewDragStarted(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewDragEnded(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewMoveFinished(MapView mapView, MapPoint mapPoint) {

    }
}
