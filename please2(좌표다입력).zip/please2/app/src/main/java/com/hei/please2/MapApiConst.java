package com.hei.please2;

class MapApiConst {
    public static final String DAUM_MAPS_ANDROID_APP_API_KEY = "0f6c455c8ff6fa7882f541e379300830";
}
