package com.hei.please2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.ViewGroup;

import net.daum.mf.map.api.MapLayout;
import net.daum.mf.map.api.MapPOIItem;
import net.daum.mf.map.api.MapPoint;
import net.daum.mf.map.api.MapView;

public class MainActivity extends AppCompatActivity implements MapView.MapViewEventListener {
    private static final MapPoint CUSTOM_MARKER_POINT = MapPoint.mapPointWithGeoCoord(37.537229, 127.005515);
    private static final MapPoint CUSTOM_MARKER_POINT2 = MapPoint.mapPointWithGeoCoord(37.447229, 127.015515);
    private static final String Daum_API_KEY = "0f6c455c8ff6fa7882f541e379300830";
    private MapPOIItem mCustomMarker;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );

        MapView mapView = new MapView ( this );
        mapView.setDaumMapApiKey ( Daum_API_KEY );
        ViewGroup mapViewContainer = (ViewGroup) findViewById ( R.id.map_view );
        mapViewContainer.addView ( mapView );

        mapView.setMapViewEventListener ( this );
    }

    @Override
    public void onMapViewInitialized(MapView mapView) {
        mapView.setMapCenterPoint(MapPoint.mapPointWithGeoCoord(36.8099687, 127.076489), true);


        MapPOIItem marker = new MapPOIItem();
        marker.setItemName("Default Marker");
        marker.setTag(0);
        marker.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8099687, 127.076489));
        marker.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker);

//////////////////////////////////////
        MapPOIItem marker1 = new MapPOIItem();
        marker1.setItemName("Default Marker");
        marker1.setTag(0);
        marker1.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8384015, 127.085486));
        marker1.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker1.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker1);
        //////////////////////////////////////
        MapPOIItem marker2 = new MapPOIItem();
        marker2.setItemName("Default Marker");
        marker2.setTag(0);
        marker2.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8779344, 127.017400));
        marker2.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker2.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker2);
        //////////////////////////////////////
        MapPOIItem marker3 = new MapPOIItem();
        marker3.setItemName("Default Marker");
        marker3.setTag(0);
        marker3.setMapPoint(MapPoint.mapPointWithGeoCoord(127.059349, 36.7731320));
        marker3.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker3.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker3);
        //////////////////////////////////////
        MapPOIItem marker4 = new MapPOIItem();
        marker4.setItemName("Default Marker");
        marker4.setTag(0);
        marker4.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7822019, 126.992230));
        marker4.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker4.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker4);
        //////////////////////////////////////
        MapPOIItem marker5 = new MapPOIItem();
        marker5.setItemName("Default Marker");
        marker5.setTag(0);
        marker5.setMapPoint(MapPoint.mapPointWithGeoCoord(36.7807873, 127.008866));
        marker5.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker5.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker5);
        //////////////////////////////////////
        MapPOIItem marker6 = new MapPOIItem();
        marker6.setItemName("Default Marker");
        marker6.setTag(0);
        marker6.setMapPoint(MapPoint.mapPointWithGeoCoord(126.912610, 36.7466563));
        marker6.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker6.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker6);
        //////////////////////////////////////
        MapPOIItem marker7 = new MapPOIItem();
        marker7.setItemName("Default Marker");
        marker7.setTag(0);
        marker7.setMapPoint(MapPoint.mapPointWithGeoCoord(36.8636366, 126.88049));
        marker7.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker7.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

        mapView.addPOIItem(marker7);



    }

    @Override
    public void onMapViewCenterPointMoved(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewZoomLevelChanged(MapView mapView, int i) {

    }

    @Override
    public void onMapViewSingleTapped(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewDoubleTapped(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewLongPressed(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewDragStarted(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewDragEnded(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewMoveFinished(MapView mapView, MapPoint mapPoint) {

    }
}
