package com.example.offender_location5;

/**
 * Created by pjh on 2014. 9. 15..
 */
public class MapApiConst {
	// http://developers.daum.net/console
    public static final String DAUM_MAPS_ANDROID_APP_API_KEY = "0f6c455c8ff6fa7882f541e379300830";
}
