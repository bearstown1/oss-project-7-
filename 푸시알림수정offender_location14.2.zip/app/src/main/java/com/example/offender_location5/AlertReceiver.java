package com.example.offender_location5;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.location.LocationManager;
import android.media.RingtoneManager;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

public class AlertReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        boolean isEntering = intent.getBooleanExtra( LocationManager.KEY_PROXIMITY_ENTERING, false);


        if(isEntering) {
            String channelId = "channel";
            String channelName = "Channel Name";

            NotificationManager notifManager

                    = (NotificationManager) context.getSystemService  (Context.NOTIFICATION_SERVICE);


            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {

                int importance = NotificationManager.IMPORTANCE_HIGH;

                NotificationChannel mChannel = new NotificationChannel(
                        channelId, channelName, importance);

                notifManager.createNotificationChannel(mChannel);

            }

            NotificationCompat.Builder builder =
                    new NotificationCompat.Builder(context.getApplicationContext(), channelId);

            Intent notificationIntent = new Intent(context.getApplicationContext()

                    , MenuActivity.class);

            notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                    Intent.FLAG_ACTIVITY_SINGLE_TOP);

            int requestID = (int) System.currentTimeMillis();

            PendingIntent pendingIntent
                    = PendingIntent.getActivity(context.getApplicationContext()

                    , requestID

                    , notificationIntent

                    , PendingIntent.FLAG_UPDATE_CURRENT);

            builder.setContentTitle("성범죄자 주의지역") // required
                    .setContentText("성범죄자 주거지역입니다")  // required
                    .setDefaults(Notification.DEFAULT_ALL) // 알림, 사운드 진동 설정
                    .setAutoCancel(true) // 알림 터치시 반응 후 삭제

                    .setSound(RingtoneManager

                            .getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))

                    .setSmallIcon(android.R.drawable.btn_star)
                    .setLargeIcon(BitmapFactory.decodeResource(context.getResources()

                            , R.drawable.ic_launcher_background))
                    .setBadgeIconType(NotificationCompat.BADGE_ICON_LARGE)

                    .setContentIntent(pendingIntent);

            notifManager.notify(0, builder.build());


            Toast.makeText(context, "위험지역에 접근중입니다..", Toast.LENGTH_LONG).show();

        }
        else
            Toast.makeText(context, "위험지역에서 벗어납니다..", Toast.LENGTH_LONG).show();
    }
}